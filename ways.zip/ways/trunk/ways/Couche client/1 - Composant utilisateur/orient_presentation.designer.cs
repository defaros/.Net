﻿namespace ways.Couche_client._1___Composant_utilisateur
{
    partial class orient_presentation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_nom = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_prenom = new System.Windows.Forms.TextBox();
            this.tb_adresse = new System.Windows.Forms.TextBox();
            this.tb_mail = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.tb_tel = new System.Windows.Forms.MaskedTextBox();
            this.tb_date_de_naissance = new System.Windows.Forms.MaskedTextBox();
            this.lbl_erreur = new System.Windows.Forms.Label();
            this.lbl_erreur_champs = new System.Windows.Forms.Label();
            this.bnt_retour = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 176);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nom";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 218);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Adresse";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 286);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Date de naissance";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 197);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Prenom";
            // 
            // tb_nom
            // 
            this.tb_nom.Location = new System.Drawing.Point(74, 168);
            this.tb_nom.Margin = new System.Windows.Forms.Padding(2);
            this.tb_nom.Name = "tb_nom";
            this.tb_nom.Size = new System.Drawing.Size(176, 20);
            this.tb_nom.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 241);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(26, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Mail";
            // 
            // tb_prenom
            // 
            this.tb_prenom.Location = new System.Drawing.Point(74, 191);
            this.tb_prenom.Margin = new System.Windows.Forms.Padding(2);
            this.tb_prenom.Name = "tb_prenom";
            this.tb_prenom.Size = new System.Drawing.Size(176, 20);
            this.tb_prenom.TabIndex = 6;
            // 
            // tb_adresse
            // 
            this.tb_adresse.Location = new System.Drawing.Point(74, 214);
            this.tb_adresse.Margin = new System.Windows.Forms.Padding(2);
            this.tb_adresse.Name = "tb_adresse";
            this.tb_adresse.Size = new System.Drawing.Size(176, 20);
            this.tb_adresse.TabIndex = 8;
            // 
            // tb_mail
            // 
            this.tb_mail.Location = new System.Drawing.Point(74, 236);
            this.tb_mail.Margin = new System.Windows.Forms.Padding(2);
            this.tb_mail.Name = "tb_mail";
            this.tb_mail.Size = new System.Drawing.Size(176, 20);
            this.tb_mail.TabIndex = 9;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(360, 312);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(78, 23);
            this.button1.TabIndex = 10;
            this.button1.Text = "Suivant";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 264);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Telephone";
            // 
            // tb_tel
            // 
            this.tb_tel.Location = new System.Drawing.Point(74, 257);
            this.tb_tel.Mask = "00 00 00 00 00";
            this.tb_tel.Name = "tb_tel";
            this.tb_tel.Size = new System.Drawing.Size(175, 20);
            this.tb_tel.TabIndex = 12;
            // 
            // tb_date_de_naissance
            // 
            this.tb_date_de_naissance.Location = new System.Drawing.Point(111, 279);
            this.tb_date_de_naissance.Mask = "00/00/0000";
            this.tb_date_de_naissance.Name = "tb_date_de_naissance";
            this.tb_date_de_naissance.Size = new System.Drawing.Size(138, 20);
            this.tb_date_de_naissance.TabIndex = 13;
            this.tb_date_de_naissance.ValidatingType = typeof(System.DateTime);
            // 
            // lbl_erreur
            // 
            this.lbl_erreur.AutoSize = true;
            this.lbl_erreur.ForeColor = System.Drawing.Color.Red;
            this.lbl_erreur.Location = new System.Drawing.Point(255, 241);
            this.lbl_erreur.Name = "lbl_erreur";
            this.lbl_erreur.Size = new System.Drawing.Size(85, 13);
            this.lbl_erreur.TabIndex = 14;
            this.lbl_erreur.Text = "E-mail incorrecte";
            // 
            // lbl_erreur_champs
            // 
            this.lbl_erreur_champs.AutoSize = true;
            this.lbl_erreur_champs.ForeColor = System.Drawing.Color.Red;
            this.lbl_erreur_champs.Location = new System.Drawing.Point(108, 101);
            this.lbl_erreur_champs.Name = "lbl_erreur_champs";
            this.lbl_erreur_champs.Size = new System.Drawing.Size(211, 13);
            this.lbl_erreur_champs.TabIndex = 15;
            this.lbl_erreur_champs.Text = "Attention! Veuillez remplir les champs vides!";
            // 
            // bnt_retour
            // 
            this.bnt_retour.Location = new System.Drawing.Point(280, 312);
            this.bnt_retour.Name = "bnt_retour";
            this.bnt_retour.Size = new System.Drawing.Size(75, 23);
            this.bnt_retour.TabIndex = 16;
            this.bnt_retour.Text = "Retour";
            this.bnt_retour.UseVisualStyleBackColor = true;
            this.bnt_retour.Click += new System.EventHandler(this.bnt_retour_Click);
            // 
            // orient_presentation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(447, 344);
            this.Controls.Add(this.bnt_retour);
            this.Controls.Add(this.lbl_erreur_champs);
            this.Controls.Add(this.lbl_erreur);
            this.Controls.Add(this.tb_date_de_naissance);
            this.Controls.Add(this.tb_tel);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tb_mail);
            this.Controls.Add(this.tb_adresse);
            this.Controls.Add(this.tb_prenom);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tb_nom);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "orient_presentation";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "orient_presentation";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.orient_presentation_FormClosing);
            this.Load += new System.EventHandler(this.orient_presentation_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_nom;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_prenom;
        private System.Windows.Forms.TextBox tb_adresse;
        private System.Windows.Forms.TextBox tb_mail;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.MaskedTextBox tb_tel;
        private System.Windows.Forms.MaskedTextBox tb_date_de_naissance;
        private System.Windows.Forms.Label lbl_erreur;
        private System.Windows.Forms.Label lbl_erreur_champs;
        private System.Windows.Forms.Button bnt_retour;
    }
}